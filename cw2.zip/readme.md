# Game Project - Read Me

## Overview
This text-based game features strategic combat and room navigation. Players must carefully choose their actions to progress. The game has specific rules for combat interactions and room exits.

## Attack Logic
1. **Effective Attacks**:
   - If the enemy can be killed by the specified object, the object's durability only reduces by 1, and the enemy is killed.
   - For example:
     ```
     Command1: attack
     Command2: enemyID
     Command3: objectID
     ```

2. **Ineffective Attacks**:
   - If the enemy is not to be killed by the object but the player uses it anyway, the object's durability is reduced by the same amount as the enemy's aggressiveness.
   - For example:
     ```
     Command1: attack
     Command2: enemyID
     Command3: otherObjectID
     ```

3. **Exiting Rooms with Enemies**:
   - If a player chooses to exit a room without defeating the enemy, their health is reduced by the amount of the enemy's aggressiveness.

## Input Format
Commands should be provided in separate lines. Each part of a command is entered separately for clear and sequential processing.

- For a command like `look room`, enter it as:
    ```
    Command1: look
    Command2: room
    Command3: 
    ```

## Playing the Game
- Start the game and follow the on-screen instructions.
- Use the combat mechanics wisely to defeat enemies or strategically decide when to retreat.
- Remember, your decisions will impact your character's health and the durability of your items.


## Combat and Attack Mechanics

1. **Efficient Attacks with Correct Weapon**:
   - When you attack an enemy using the correct object (weapon), the battle is highly efficient. The object's durability only decreases slightly (by 1 point), and the enemy is successfully defeated.

2. **Inefficient Attacks with Incorrect Weapon**:
   - Attacking an enemy with an object not intended to defeat them leads to a less efficient battle. In such cases, the object's durability decreases significantly, equivalent to the enemy's level of aggressiveness. This reflects the struggle and extra effort required to defeat the enemy with an unsuitable weapon.

3. **Consequence of Avoiding Combat**:
   - Opting to leave a room without engaging or defeating an enemy comes with a risk. If you choose to exit a room while an enemy remains undefeated, your health will diminish. The reduction in health is directly proportional to the enemy's aggressiveness, symbolizing the enemy's attack as you retreat.

These mechanics emphasize strategic decision-making in combat, urging players to choose their battles wisely and utilize their weapons effectively.

Thank you for playing, and enjoy the game!
